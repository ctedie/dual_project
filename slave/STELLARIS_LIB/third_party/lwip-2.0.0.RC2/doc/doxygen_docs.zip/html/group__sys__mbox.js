var group__sys__mbox =
[
    [ "sys_arch_mbox_fetch", "group__sys__mbox.html#ga6464cd77cf6799bd8b3d6c840166a2e8", null ],
    [ "sys_arch_mbox_tryfetch", "group__sys__mbox.html#gafab441b130b4ec417012835dbe1e497c", null ],
    [ "sys_mbox_free", "group__sys__mbox.html#gac641a45812155d2234ef80dd6412882f", null ],
    [ "sys_mbox_new", "group__sys__mbox.html#gab9793f30642de06ce87827e9adbe30cc", null ],
    [ "sys_mbox_post", "group__sys__mbox.html#ga9d068386a3c53dd01b8af99c3ef77555", null ],
    [ "sys_mbox_set_invalid", "group__sys__mbox.html#ga53ddec9d7f5500c5b1d982cd17493172", null ],
    [ "sys_mbox_trypost", "group__sys__mbox.html#gaa36345e48a49d67cbb0878cd4cbd2195", null ],
    [ "sys_mbox_valid", "group__sys__mbox.html#ga8bcfab4bd791dd33f69a778e7585275d", null ]
];