var netbiosns__opts_8h =
[
    [ "NETBIOS_LWIP_NAME", "group__netbiosns__opts.html#ga468c2ae67a79ce082ee585a438f7373b", null ],
    [ "NETBIOS_STRCMP", "group__netbiosns__opts.html#ga66f86a7ccfc468cedb19302b810e3244", null ]
];