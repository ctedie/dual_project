var netdb_8c =
[
    [ "gethostbyname_r_helper", "structgethostbyname__r__helper.html", null ],
    [ "HOSTENT_STORAGE", "netdb_8c.html#acfc1e988534c0e497599b904739f92fe", null ],
    [ "LWIP_DNS_API_HOSTENT_STORAGE", "netdb_8c.html#a768ab8ead892d6454709680340cd070e", null ],
    [ "lwip_freeaddrinfo", "netdb_8c.html#a7f65ff5982a0743849a644ef2cd15ef5", null ],
    [ "lwip_getaddrinfo", "netdb_8c.html#af356989c172a51187e22b557f22d4165", null ],
    [ "lwip_gethostbyname", "netdb_8c.html#a8adc6d35c068a073369edde71c678cbc", null ],
    [ "lwip_gethostbyname_r", "netdb_8c.html#afa229e90916f6c8d6308828f45351d2d", null ],
    [ "h_errno", "netdb_8c.html#a2a1ce3f2040007303d36c0b682b5ac10", null ]
];