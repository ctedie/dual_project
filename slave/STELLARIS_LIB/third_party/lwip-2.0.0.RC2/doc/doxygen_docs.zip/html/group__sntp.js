var group__sntp =
[
    [ "Options", "group__sntp__opts.html", "group__sntp__opts" ],
    [ "sntp_enabled", "group__sntp.html#ga3fe5254e5a056fca80802d9f26b9c3c5", null ],
    [ "sntp_getoperatingmode", "group__sntp.html#gae66404a551d5cef420cf844a71356fae", null ],
    [ "sntp_getserver", "group__sntp.html#ga2a28523cb9f2b5b025a4818bc2c1afc1", null ],
    [ "sntp_init", "group__sntp.html#ga9b300c6616de60524c85ea40bf70e2ba", null ],
    [ "sntp_setoperatingmode", "group__sntp.html#gaae94fb2adadbf9667e9597f8a45bf120", null ],
    [ "sntp_setserver", "group__sntp.html#ga4fa038dcea66349fafdbe1cc3e52ff3a", null ],
    [ "sntp_stop", "group__sntp.html#ga8119fc2d1ff7ff6eba511cc9c7167488", null ]
];