var group__callbackstyle__api =
[
    [ "DNS", "group__dns.html", "group__dns" ],
    [ "IPv4", "group__ip4.html", "group__ip4" ],
    [ "IPv6", "group__ip6.html", "group__ip6" ],
    [ "Network interface (NETIF)", "group__netif.html", "group__netif" ],
    [ "RAW API", "group__raw__api.html", "group__raw__api" ]
];