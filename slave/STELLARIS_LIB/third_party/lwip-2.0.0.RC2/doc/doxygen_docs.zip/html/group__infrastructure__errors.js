var group__infrastructure__errors =
[
    [ "ERR_ABRT", "group__infrastructure__errors.html#ga0629f0c91a328ccf469923287db34d7f", null ],
    [ "ERR_ALREADY", "group__infrastructure__errors.html#gaf1ef615b4b72fe63492e9fcc458cb31a", null ],
    [ "ERR_ARG", "group__infrastructure__errors.html#ga8700518a3e3d0c7a4439a37dcbcf2143", null ],
    [ "ERR_BUF", "group__infrastructure__errors.html#gae1dcf352601ec4d3b700910df24f863d", null ],
    [ "ERR_CLSD", "group__infrastructure__errors.html#gaf26c7107aefe53fdfef57965fd9b937d", null ],
    [ "ERR_CONN", "group__infrastructure__errors.html#ga88c4da0bf5d6a4410f6cfb864a5f04ce", null ],
    [ "ERR_IF", "group__infrastructure__errors.html#gafc95037d229067130084274ed078ef63", null ],
    [ "ERR_INPROGRESS", "group__infrastructure__errors.html#gae07d802f89a09e400c3adbc01aa24968", null ],
    [ "ERR_ISCONN", "group__infrastructure__errors.html#ga2906f5b6f8b7c277830e5695f92b9ad6", null ],
    [ "ERR_MEM", "group__infrastructure__errors.html#ga6ab63185cc5dff3c50c61d99bdf98369", null ],
    [ "ERR_OK", "group__infrastructure__errors.html#ga98c763adfeea8e9831c46ec269e47ae9", null ],
    [ "ERR_RST", "group__infrastructure__errors.html#ga1ef610d9fa2a04aef05d5410a2b3b65a", null ],
    [ "ERR_RTE", "group__infrastructure__errors.html#ga99462c1105f849cc0db4c87261e0b63d", null ],
    [ "ERR_TIMEOUT", "group__infrastructure__errors.html#gaedcf61ffa26ceba66e9995937de74d64", null ],
    [ "ERR_USE", "group__infrastructure__errors.html#ga7a7ef5bec7c4a01857f4430b82915a0a", null ],
    [ "ERR_VAL", "group__infrastructure__errors.html#gaa803bb0b2c462e8b1f60459dd1f54bc9", null ],
    [ "ERR_WOULDBLOCK", "group__infrastructure__errors.html#ga9ffc9c4f78a546508cd265dddc126ab8", null ],
    [ "err_t", "group__infrastructure__errors.html#gaf02d9da80fd66b4f986d2c53d7231ddb", null ]
];