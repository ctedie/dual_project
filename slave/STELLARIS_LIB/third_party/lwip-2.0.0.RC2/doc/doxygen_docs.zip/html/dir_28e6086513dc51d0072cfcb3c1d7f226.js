var dir_28e6086513dc51d0072cfcb3c1d7f226 =
[
    [ "sys", "dir_a05c63b09d645ddb1c0154724b085a55.html", "dir_a05c63b09d645ddb1c0154724b085a55" ],
    [ "netdb.h", "posix_2netdb_8h.html", null ]
];