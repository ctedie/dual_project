var group__sys__mutex =
[
    [ "sys_mutex_free", "group__sys__mutex.html#ga16336ce68b741e98204102ca4bc84dd9", null ],
    [ "sys_mutex_lock", "group__sys__mutex.html#ga4d4eb9afe5965fa2661dd54ff55d616a", null ],
    [ "sys_mutex_new", "group__sys__mutex.html#ga38e7dae1fd88b338eb1cd97f110f3897", null ],
    [ "sys_mutex_set_invalid", "group__sys__mutex.html#ga3f392725971dc837aa56dd7e45fa7ca8", null ],
    [ "sys_mutex_unlock", "group__sys__mutex.html#ga5568f68898fe9d5735f9ce2f665624fb", null ],
    [ "sys_mutex_valid", "group__sys__mutex.html#gaebe83ba90a6d9c23cdb3eb5d49562c4a", null ]
];