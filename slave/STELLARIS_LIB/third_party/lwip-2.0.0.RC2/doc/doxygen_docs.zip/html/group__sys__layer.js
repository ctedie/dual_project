var group__sys__layer =
[
    [ "OS abstraction layer", "group__sys__os.html", "group__sys__os" ],
    [ "Time", "group__sys__time.html", "group__sys__time" ],
    [ "Critical sections", "group__sys__prot.html", "group__sys__prot" ]
];