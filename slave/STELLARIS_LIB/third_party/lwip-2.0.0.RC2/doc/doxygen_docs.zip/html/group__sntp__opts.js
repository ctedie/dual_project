var group__sntp__opts =
[
    [ "SNTP_CHECK_RESPONSE", "group__sntp__opts.html#ga7d4e12d90912d486e64f289d7f3ca446", null ],
    [ "SNTP_DEBUG", "group__sntp__opts.html#ga25c6f9c14c17e218d110d826b09f8d91", null ],
    [ "SNTP_GET_SERVERS_FROM_DHCP", "group__sntp__opts.html#ga961a61eef942ab5378cff1e3742b3ade", null ],
    [ "SNTP_GET_SYSTEM_TIME", "group__sntp__opts.html#ga7196defff10bfd1ec2909ca2f37f0d63", null ],
    [ "SNTP_MAX_SERVERS", "group__sntp__opts.html#ga5d9dc0827f402849f5c18d44e311dbc2", null ],
    [ "SNTP_PORT", "group__sntp__opts.html#gacbee62c27f54371fc2c5259a834a0f9b", null ],
    [ "SNTP_RECV_TIMEOUT", "group__sntp__opts.html#ga44cf26b9b19832d88599244711a12d08", null ],
    [ "SNTP_RETRY_TIMEOUT", "group__sntp__opts.html#ga86d651d8eb07687208308deef95a23ba", null ],
    [ "SNTP_RETRY_TIMEOUT_EXP", "group__sntp__opts.html#gafdb7e98f608cc429188d7dac356614c2", null ],
    [ "SNTP_RETRY_TIMEOUT_MAX", "group__sntp__opts.html#gafde10b3ed7cb4bb2cd2c4daa389db699", null ],
    [ "SNTP_SERVER_DNS", "group__sntp__opts.html#gaef477c145ae404d77188b26b79b6996f", null ],
    [ "SNTP_SERVER_DNS", "group__sntp__opts.html#gaef477c145ae404d77188b26b79b6996f", null ],
    [ "SNTP_SET_SYSTEM_TIME", "group__sntp__opts.html#gaa0360566aa2db7483f0677ce8d8dc711", null ],
    [ "SNTP_STARTUP_DELAY", "group__sntp__opts.html#ga22017d43da7d4bf8d42e786b4ced4dfa", null ],
    [ "SNTP_STARTUP_DELAY_FUNC", "group__sntp__opts.html#gae082c2f3044d500ca5e1be1d4928de75", null ],
    [ "SNTP_UPDATE_DELAY", "group__sntp__opts.html#ga9232c56443115be05a2f852eba21979c", null ]
];