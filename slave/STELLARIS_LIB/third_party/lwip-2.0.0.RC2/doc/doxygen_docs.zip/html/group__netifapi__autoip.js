var group__netifapi__autoip =
[
    [ "netifapi_autoip_start", "group__netifapi__autoip.html#gaa9d068f49145f42c2ffe9352bd3ef6ef", null ],
    [ "netifapi_autoip_stop", "group__netifapi__autoip.html#gac1cfcad04e96da562dce5d4bd9f5a17d", null ]
];