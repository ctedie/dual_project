var mem_8c =
[
    [ "mem", "structmem.html", "structmem" ],
    [ "MIN_SIZE", "mem_8c.html#a278694c2333c9826f21ddd2c2d220f66", null ],
    [ "mem_calloc", "mem_8c.html#ab0bdc525971701883f2065e7fb257a24", null ],
    [ "mem_free", "mem_8c.html#a65169147c44e9db60d997819af9b455c", null ],
    [ "mem_init", "mem_8c.html#a44a136e3b70c36abb6f8dc060c778113", null ],
    [ "mem_malloc", "mem_8c.html#a932aa40d85b14cb7331625e012d12335", null ],
    [ "mem_trim", "mem_8c.html#a2f0214c1c0d4acf856fb3ec76818a5a9", null ],
    [ "ram_heap", "mem_8c.html#a8b8f6d33593f95016832b70de1a3e4e0", null ]
];