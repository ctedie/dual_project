var netifapi_8h =
[
    [ "netifapi_autoip_start", "group__netifapi__autoip.html#gaa9d068f49145f42c2ffe9352bd3ef6ef", null ],
    [ "netifapi_autoip_stop", "group__netifapi__autoip.html#gac1cfcad04e96da562dce5d4bd9f5a17d", null ],
    [ "netifapi_dhcp_inform", "group__netifapi__dhcp4.html#ga4cb8477566239180d0a53b5ee79f418b", null ],
    [ "netifapi_dhcp_release", "group__netifapi__dhcp4.html#ga3b058ff8a20b7ce364d68fc97ae563ad", null ],
    [ "netifapi_dhcp_renew", "group__netifapi__dhcp4.html#ga4b539fcfbb253d572175797e7a5b42a1", null ],
    [ "netifapi_dhcp_start", "group__netifapi__dhcp4.html#ga200b42c361951864e8fdef8078730d57", null ],
    [ "netifapi_dhcp_stop", "group__netifapi__dhcp4.html#gaf7f34a081df720c08129878217fa2116", null ],
    [ "netifapi_netif_remove", "group__netifapi__netif.html#ga2e9ea2a055e0879ff1af6a5b09926e8b", null ],
    [ "netifapi_netif_set_default", "group__netifapi__netif.html#ga862d6cfa5d36b2c36d7b1671e8d95ccf", null ],
    [ "netifapi_netif_set_down", "group__netifapi__netif.html#ga70a72e1a22afa373ba26a3f2d3e28d29", null ],
    [ "netifapi_netif_set_up", "group__netifapi__netif.html#ga65e666c72d3068280e7bb96eb24999a2", null ],
    [ "netifapi_netif_add", "group__netifapi__netif.html#gacc063c5a3071e34eec7376651e35a519", null ],
    [ "netifapi_netif_common", "netifapi_8h.html#a26fd83042b53b2ff82e15262ed72f0a7", null ],
    [ "netifapi_netif_set_addr", "group__netifapi__netif.html#ga31755ea6dbb213236bfce19bcbe8c973", null ]
];