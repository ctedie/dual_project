var group__threadsafe__api =
[
    [ "Netconn API", "group__netconn.html", "group__netconn" ],
    [ "NETIF API", "group__netifapi.html", "group__netifapi" ],
    [ "Socket API", "group__socket.html", "group__socket" ]
];