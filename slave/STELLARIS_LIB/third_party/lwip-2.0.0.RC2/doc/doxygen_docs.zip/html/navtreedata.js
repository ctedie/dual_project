var NAVTREE =
[
  [ "lwIP 2.0.0", "index.html", [
    [ "Overview", "index.html", null ],
    [ "Upgrading", "upgrading.html", null ],
    [ "How to contribute to lwIP", "contrib.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"globals_t.html",
"group__ipaddr.html#ga44f9ada14c65d17aecf802d82eb273c5",
"group__lwip__opts__igmp.html#gadaf25915ae1fd69c0943ef68cbb38923",
"group__lwip__opts__stats.html",
"group__netconn__common.html#ggaaba260d28d105fb4bce9185fd0300d91a2c7f548d26f6c411f084b6c59247b60e",
"group__raw__raw.html#ga3292b7ed2271ac29983edcef16dcbc11",
"group__socket.html#gac3fcaa0ffcb70a1b5237dabfdaf58cc2",
"index.html",
"mld6_8c.html",
"sntp_8c.html",
"structsnmp__varbind.html#ab094577fac6c7cc16ad666c9970cdb85"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';