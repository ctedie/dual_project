var modules =
[
    [ "lwIP", "group__lwip.html", "group__lwip" ],
    [ "Infrastructure", "group__infrastructure.html", "group__infrastructure" ],
    [ "Callback-style APIs", "group__callbackstyle__api.html", "group__callbackstyle__api" ],
    [ "Thread-safe APIs", "group__threadsafe__api.html", "group__threadsafe__api" ],
    [ "Addons", "group__addons.html", "group__addons" ],
    [ "Applications", "group__apps.html", "group__apps" ]
];